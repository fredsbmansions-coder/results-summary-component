# Results Summary Component

A beginner-friendly HTML and CSS project for the Frontend Mentor Results Summary Component challenge.

## Files
- `index.html` — the page content
- `styles.css` — the styling and mobile responsiveness
- `assets/images/` — the four category icons

## Preview on your laptop
1. Download and extract this ZIP file.
2. Open the extracted `Results-Summary-Component` folder in VS Code.
3. Open `index.html`.
4. If you have the Live Server extension, right-click the page and choose **Open with Live Server**.

## Put it online with GitHub and Vercel
1. Sign in to GitHub and create a new repository named `results-summary-component`.
2. Upload the files and folders inside this project folder to that repository. Make sure `index.html`, `styles.css`, and the `assets` folder are in the repository's main/root level.
3. Sign in to Vercel using your GitHub account.
4. Choose **Add New → Project**, import `results-summary-component`, and deploy it.
5. Vercel will give you a website link to share with your instructor.

This project is a static HTML/CSS site, so it does not need a build command. You do need to complete the GitHub and Vercel steps in your own accounts; this ZIP does not publish it automatically.
